import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { IntroSection } from './components/IntroSection';
import { ProductSection } from './components/ProductSection';
import { Process } from './components/Process';
import { WhyChoose } from './components/WhyChoose';
import { Waitlist } from './components/Waitlist';
import { FAQ } from './components/FAQ';
import { Footer } from './components/Footer';
import { xerfProducts, xerfTreatmentAreas, faqs } from './data';

function App() {
  return (
    <div className="min-h-screen bg-[#fbfaf8] selection:bg-[#2C2B29] selection:text-white font-sans">
      <Navbar />
      <Hero />
      <IntroSection />
      
      <ProductSection 
        title="What is XERF?"
        number="01"
        description="XERF is the first treatment of its kind — a non-invasive skin tightening treatment that uses advanced multi-frequency radiofrequency technology to stimulate collagen production and firm the skin from the inside out. Unlike treatments that only target the skin's surface, XERF reshapes skin at deeper levels for better, more visible results."
        products={xerfProducts}
        bgColor="#F5F3ED"
      />
      
      <div className="w-full h-auto">
        <img 
          src="https://cdn.prod.website-files.com/690106919d240fb80310c681/691f6e6b96f21d15d87435da_f059200d120511b9b3d33da3f820b3e2_691de821d516f4bddc76710f_187e0886-c696-4348-a6d6-a92e1d700a42%20%281%29%20%281%29-topaz-upscale-3x-min%201.webp" 
          alt="Banner"
          className="w-full h-[50vh] md:h-[70vh] object-cover"
        />
      </div>

      <ProductSection 
        title="Treatment Areas"
        number="02"
        description="XERF is highly versatile and effective on both face and body, especially in areas with mild to moderate skin laxity."
        products={xerfTreatmentAreas}
        bgColor="#D1D0C8"
      />

      <Process />
      
      <WhyChoose />
      
      <FAQ faqs={faqs} />
      
      <Waitlist />
      
      <Footer />
    </div>
  );
}

export default App;
