import { ArrowRight } from 'lucide-react';
import { Button } from './ui/Button';

export function Hero() {
  return (
    <section className="relative w-full h-[90vh] md:h-screen pt-20 overflow-hidden bg-[#2C2B29]">
      <div className="absolute inset-0 z-0">
        <img 
          src="https://cdn.prod.website-files.com/690106919d240fb80310c681/691f6a79c4384ce2ad7ef6bc_b0bbbb59bbdbd58431eb5e20a147829c_Screenshot%202025-11-20%20at%201.22.12%E2%80%AFPM.webp"
          className="w-full h-full object-cover opacity-60"
          alt="Hero background"
        />
      </div>

      <div className="relative z-10 w-full h-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col justify-end pb-24 md:pb-32">
        <div className="max-w-3xl">
          <p className="text-white/80 font-mono text-sm uppercase tracking-widest mb-4">FDA Cleared</p>
          <h1 className="text-5xl md:text-7xl lg:text-[80px] font-serif text-white tracking-tight leading-[1.05] mb-6">
            Instantly tighten and lift skin with multi-frequency RF technology
          </h1>
          <p className="text-lg md:text-xl text-white/90 leading-relaxed font-medium mb-10 max-w-2xl">
            If you're noticing sagging skin, loss of firmness, or the early signs of aging but aren't ready for surgery, XERF introduces a more advanced approach to skin tightening in New York City. As the world's first multi-frequency monopolar RF treatment, XERF uses dual frequencies to deliver energy with greater precision, helping tighten, smooth, and lift skin exactly where it needs it most.
          </p>
          <div className="flex flex-col sm:flex-row gap-4">
            <Button variant="primary" withArrow className="bg-white text-black hover:bg-gray-100">
              Join the Waitlist
            </Button>
            <Button variant="outline" className="text-white border-white hover:bg-white/10">
              Learn More
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
}
