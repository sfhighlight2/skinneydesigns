import React from 'react';
import { Sparkles, Activity, ShieldCheck, TrendingUp } from 'lucide-react';

export function IntroSection() {
  return (
    <section className="pt-20 pb-24 md:pt-32 md:pb-32 bg-[#FAF9F5] relative overflow-hidden">
      {/* Background Gradient to match the aesthetic */}
      <div className="absolute inset-0 bg-gradient-to-r from-[#FAF9F5] via-[#FCFBF8] to-[#F1EFE6] opacity-60 z-0"></div>
      
      <div className="max-w-[1400px] mx-auto px-4 sm:px-6 lg:px-8 relative z-10 w-full">
        {/* Top 50/50 Split Section */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-8 items-center mb-24 md:mb-32">
          
          {/* Left: Image */}
          <div className="relative w-full h-[400px] sm:h-[500px] lg:h-[700px] xl:h-[800px] -ml-4 sm:-ml-12 lg:-ml-24 xl:-ml-32">
            <img 
              src="https://cdn.prod.website-files.com/690106919d240fb80310c681/69272fc7883c948c9eda29b5_good-life-hero-render.avif" 
              alt="SKINNEY Medspa Presentation"
              className="absolute left-0 bottom-0 w-[120%] lg:w-[130%] max-w-none object-contain object-left-bottom drop-shadow-xl saturate-[1.05]"
            />
          </div>

          {/* Right: Text Content */}
          <div className="flex flex-col max-w-[620px] lg:pl-10 xl:pl-20 mt-8 lg:mt-0">
            <h2 className="text-[52px] sm:text-[64px] lg:text-[76px] xl:text-[88px] leading-[0.92] tracking-tighter font-sans text-[#1c1c1c] mb-8 font-medium">
              Making happiness<br />
              and healthiness<br />
              easy to achieve
            </h2>
            
            <div className="w-full border-t border-dotted border-gray-400 mb-8 opacity-70"></div>
            
            <p className="text-[17px] sm:text-[18px] text-[#4A4A4A] leading-[1.6] mb-10 max-w-[460px]">
              Discover a healthier, more vibrant you with SKINNEY Medspa. Explore our treatments today and take the first step towards a fuller, more rewarding life.
            </p>
            
            <div>
              <a href="#waitlist" className="bg-[#333333] text-white px-8 py-3.5 text-[15px] font-medium hover:bg-black transition-colors shadow-sm inline-flex items-center justify-center rounded-[3px]">
                Find your treatment
              </a>
            </div>
          </div>
        </div>

        {/* 4-Column Feature Row */}
        <div className="border-t border-gray-200/60 pt-20">
          <h3 className="text-3xl md:text-4xl lg:text-5xl font-serif mb-12 text-[#2C2B29]">The world's first <span className="text-gray-400">multi-frequency RF</span></h3>
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-8">
            <Feature icon={<Activity className="w-6 h-6" />} title="World's First Multi-Frequency RF" desc="XERF is the first system to use dual monopolar RF frequencies (6.78 MHz and 2 MHz), treating both surface and deep structural layers in one session." />
            <Feature icon={<ShieldCheck className="w-6 h-6" />} title="Medically Supervised Experts" desc="Every treatment is delivered by SKINNEY's highly trained, medically supervised provider team with deep expertise in energy-based skin tightening." />
            <Feature icon={<Sparkles className="w-6 h-6" />} title="Never-Numb™ Comfort" desc="Integrated cooling and pulse technology keeps treatments comfortable while delivering powerful energy where it matters most." />
            <Feature icon={<TrendingUp className="w-6 h-6" />} title="Real, Visible Results" desc="Instant tightening from collagen contraction, plus progressive lifting and firming as your skin rebuilds over the following weeks." />
          </div>
        </div>
      </div>
    </section>
  );
}

function Feature({ icon, title, desc }: { icon: React.ReactNode, title: string, desc: string }) {
  return (
    <div className="flex flex-col items-start gap-4">
      <div className="p-4 bg-white/60 backdrop-blur rounded-2xl text-gray-700 border border-gray-200/50 shadow-[0_2px_10px_-4px_rgba(0,0,0,0.05)]">
        {icon}
      </div>
      <h4 className="text-[20px] font-semibold text-[#1c1c1c] leading-snug">{title}</h4>
      <p className="text-[15px] text-gray-600 leading-relaxed font-medium">{desc}</p>
    </div>
  );
}
