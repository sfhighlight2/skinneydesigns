import { ChevronDown, Search, CalendarPlus, Menu } from 'lucide-react';

export function Navbar() {
  return (
    <nav className="fixed top-0 left-0 right-0 z-50 bg-white border-b border-gray-100 font-sans">
      <div className="w-full px-6 md:px-12 lg:px-16">
        <div className="flex justify-between items-center h-[90px]">
          {/* Mobile Menu Button */}
          <div className="flex xl:hidden items-center">
            <button className="text-black">
              <Menu className="w-6 h-6" />
            </button>
          </div>

          {/* Left Nav Elements */}
          <div className="hidden xl:flex flex-1 items-center justify-end pr-10 2xl:pr-20 space-x-10 2xl:space-x-12">
            <NavLink text="ABOUT" hasDropdown />
            <NavLink text="LOCATIONS" hasDropdown />
            <NavLink text="TREATMENTS" hasDropdown />
            <NavLink text="MEMBERSHIPS" />
          </div>

          {/* Center Logo */}
          <div className="flex-shrink-0 flex flex-col items-center justify-center cursor-pointer pt-1">
            <div className="flex items-start">
              <span className="font-sans text-[48px] tracking-tight text-black leading-none flex items-center">
                <span className="font-semibold">SK</span>
                <span className="font-light tracking-[0.05em] ml-0.5 uppercase" style={{
                  backgroundImage: 'radial-gradient(circle, #000 45%, transparent 50%)',
                  backgroundSize: '4px 4px',
                  WebkitBackgroundClip: 'text',
                  color: 'transparent'
                }}>INNEY</span>
                <sup className="text-xl font-light ml-1 relative -top-3">®</sup>
              </span>
            </div>
            <span className="font-sans text-[12px] tracking-[0.45em] text-gray-500 uppercase mt-0.5 ml-1 leading-none">
              medspa + wellness
            </span>
          </div>

          {/* Right Nav Elements */}
          <div className="hidden xl:flex flex-1 items-center justify-between pl-10 2xl:pl-20">
            <div className="flex items-center space-x-10 2xl:space-x-12">
              <NavLink text="SCHEDULE" hasDropdown />
              <NavLink text="SPECIALS" />
              <NavLink text="SHOP" hasDropdown />
            </div>
            
            <div className="flex items-center space-x-8 ml-auto">
              <button className="text-black hover:opacity-70 transition-opacity">
                <Search className="w-6 h-6" strokeWidth={2} />
              </button>
              <button className="flex items-center gap-3 border-2 border-black rounded-full px-8 py-3 hover:bg-gray-50 transition-colors">
                <CalendarPlus className="w-5 h-5 mb-0.5" strokeWidth={1.5} />
                <span className="text-sm font-bold tracking-[0.1em]">BOOK NOW</span>
              </button>
            </div>
          </div>

          {/* Spacer for mobile to center logo */}
          <div className="xl:hidden w-6"></div>
        </div>
      </div>
    </nav>
  );
}

function NavLink({ text, hasDropdown }: { text: string; hasDropdown?: boolean }) {
  return (
    <a href="#" className="flex items-center gap-2 text-[13px] font-bold tracking-[0.1em] text-black hover:text-gray-500 transition-colors">
      {text}
      {hasDropdown && <ChevronDown className="w-4 h-4 mt-0.5" strokeWidth={2.5} />}
    </a>
  );
}

