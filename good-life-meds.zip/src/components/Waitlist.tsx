import React from 'react';
import { Button } from './ui/Button';

export function Waitlist() {
  return (
    <section className="py-24 bg-[#F5F3ED]" id="waitlist">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-white rounded-[40px] p-8 md:p-16 shadow-sm border border-[#2C2B29]/10 text-center">
          <h2 className="text-4xl md:text-5xl font-serif text-[#2C2B29] mb-6">Be the first to experience XERF in NYC</h2>
          <p className="text-lg text-gray-600 mb-10 max-w-3xl mx-auto">
            XERF Skin Tightening is coming to New York City, bringing one of the most advanced non-surgical tightening technologies to patients seeking real, visible results without downtime. As XERF's popularity spreads, early access spots will fill quickly.
          </p>
          
          <div className="text-left bg-gray-50 rounded-3xl p-8 mb-10 border border-gray-100 max-w-2xl mx-auto">
            <h3 className="font-semibold text-[#2C2B29] mb-4 text-lg">Join the waitlist to secure your spot. You'll receive:</h3>
            <ul className="space-y-3">
              <li className="flex gap-3 text-gray-600">
                 <span className="text-[#2C2B29] font-bold">•</span>
                 Early access to appointment scheduling
              </li>
              <li className="flex gap-3 text-gray-600">
                 <span className="text-[#2C2B29] font-bold">•</span>
                 Priority placement on the first available treatment dates
              </li>
              <li className="flex gap-3 text-gray-600">
                 <span className="text-[#2C2B29] font-bold">•</span>
                 Exclusive pricing and launch promotions
              </li>
            </ul>
          </div>

          <form className="max-w-2xl mx-auto flex flex-col gap-4 text-left">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <input type="text" placeholder="First Name" className="w-full px-5 py-4 rounded-xl border border-gray-200 focus:border-[#2C2B29] focus:outline-none transition-colors" />
              <input type="text" placeholder="Last Name" className="w-full px-5 py-4 rounded-xl border border-gray-200 focus:border-[#2C2B29] focus:outline-none transition-colors" />
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <input type="email" placeholder="Email Address" className="w-full px-5 py-4 rounded-xl border border-gray-200 focus:border-[#2C2B29] focus:outline-none transition-colors" />
              <input type="tel" placeholder="Phone Number" className="w-full px-5 py-4 rounded-xl border border-gray-200 focus:border-[#2C2B29] focus:outline-none transition-colors" />
            </div>
            <select className="w-full px-5 py-4 rounded-xl border border-gray-200 focus:border-[#2C2B29] focus:outline-none transition-colors bg-white text-gray-500">
               <option value="">Preferred Location (NYC)</option>
               <option value="flatiron">Flatiron</option>
               <option value="soho">Soho</option>
            </select>
            
            <Button variant="primary" className="py-4 text-lg mt-4 w-full md:w-auto md:ml-auto">
              Reserve My Spot
            </Button>
          </form>
        </div>
      </div>
    </section>
  );
}
