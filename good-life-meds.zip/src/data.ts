import { Product, FAQ } from './types';

export const xerfProducts: Product[] = [
  {
    id: 'xerf-1',
    name: 'Targets Multiple Skin Layers',
    category: 'Surface, mid, and deep tissue treated in one session for comprehensive tightening.',
    description: '',
    image: 'https://cdn.prod.website-files.com/69025c7a06f6a8cfc861e948/6938b16b23d5156e0736842b_TIRZEPATIDE%20VIAL%201-p-800.avif',
    color: '#2C2B29',
    rx: false,
    link: '#waitlist',
    buttonText: 'Learn More'
  },
  {
    id: 'xerf-2',
    name: 'Stimulates Collagen and Elastin',
    category: 'Controlled heat activates your body\'s natural regenerative processes for long-term firmness.',
    description: '',
    image: 'https://cdn.prod.website-files.com/69025c7a06f6a8cfc861e948/6927afc3be2c83241aaf831e_SEMAGLUTIDE_SPIN%201-p-800.avif',
    color: '#2C2B29',
    rx: false,
    link: '#waitlist',
    buttonText: 'Learn More'
  },
  {
    id: 'xerf-3',
    name: 'Instant + Progressive Lift',
    category: 'Contracts existing collagen for immediate results, then remodels deeper support layers for ongoing improvement over weeks.',
    description: '',
    image: 'https://cdn.prod.website-files.com/69025c7a06f6a8cfc861e948/69af1e10e14dfd45ab045d15_Wegovy%20Pill%20Transparent-p-800.png',
    color: '#2C2B29',
    rx: false,
    link: '#waitlist',
    buttonText: 'Learn More'
  }
];

export const xerfTreatmentAreas: Product[] = [
  {
    id: 'area-1',
    name: 'Face',
    category: 'Jawline and jowls, cheeks and midface, under the chin (submental area).',
    description: '',
    image: 'https://cdn.prod.website-files.com/69025c7a06f6a8cfc861e948/6927b609314845ca1ac05044_NAD_SPIN%201-p-800.avif',
    color: '#2C2B29',
    rx: false,
    link: '#waitlist',
    buttonText: 'Reserve Consultation'
  },
  {
    id: 'area-2',
    name: 'Neck and Décolleté',
    category: 'Lift and smooth crepey, sagging skin along the neck for a more youthful profile.',
    description: '',
    image: 'https://cdn.prod.website-files.com/69025c7a06f6a8cfc861e948/697139a0849139b4f5927963_Microdose%20GLP-1%20Cream%20Background%20-p-800.avif',
    color: '#2C2B29',
    rx: false,
    link: '#waitlist',
    buttonText: 'Reserve Consultation'
  },
  {
    id: 'area-3',
    name: 'Body',
    category: 'Abdomen, arms, and thighs — tighten loose skin without surgery or downtime.',
    description: '',
    image: 'https://cdn.prod.website-files.com/69025c7a06f6a8cfc861e948/697a8406aeeaf0e7ec2550e3_MIC%2BB12_SPIN%201-p-800.avif',
    color: '#2C2B29',
    rx: false,
    link: '#waitlist',
    buttonText: 'Reserve Consultation'
  }
];

export const faqs: FAQ[] = [
  {
    question: 'What is XERF and how is it different from other skin tightening treatments?',
    answer: 'XERF is the world\'s first multi-frequency monopolar RF treatment. While most RF systems use a single frequency targeting one skin depth, XERF combines 6.78 MHz and 2 MHz to treat surface, mid, and deep tissue layers in the same session. This produces stronger structural lifting and more visible results than traditional single-frequency RF.'
  },
  {
    question: 'Does XERF hurt? Is there downtime?',
    answer: 'No. XERF features integrated cooling and pulse technology for a Never-Numb™ experience that most patients describe as warm and comfortable. There is zero downtime — you can return to your normal activities immediately after treatment.'
  },
  {
    question: 'When will I see results?',
    answer: 'You\'ll notice immediate tightening from collagen contraction right after your session. Progressive lifting, firming, and improved skin quality continue to develop over the following weeks as your skin produces new collagen and elastin.'
  },
  {
    question: 'What areas can XERF treat?',
    answer: 'XERF works on both face and body, including the jawline, jowls, cheeks, midface, submental area (under the chin), neck, abdomen, arms, and thighs. It\'s most effective for mild to moderate skin laxity.'
  },
  {
    question: 'Is XERF safe? Is it FDA cleared?',
    answer: 'Yes. XERF is FDA cleared and performed by SKINNEY\'s medically supervised, highly trained provider team.'
  },
  {
    question: 'Is financing available?',
    answer: 'Yes. SKINNEY Medspa offers 0% APR financing for qualified patients.'
  }
];
